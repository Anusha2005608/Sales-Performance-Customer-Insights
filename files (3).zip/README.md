# Sales Performance & Customer Insights Dashboard

A beginner-friendly but professional Data Analyst portfolio project demonstrating end-to-end analysis of a retail sales dataset using **Excel, Python, and SQL**.

---

## Project Overview

This project simulates a real retail company's 2025 sales data and turns it into a set of analyst-ready deliverables: a cleaned dataset, an interactive Excel dashboard, a Python analysis pipeline, SQL queries for a relational database, and a written business-insights report. The goal is to show the full workflow a Data Analyst is expected to run — from raw, messy data to a polished, recruiter-friendly output — without over-engineering it.

## Business Problem

A retail company sells across multiple product categories, states, and sales channels (Online, In-Store, Mobile App) but has no consolidated view of its performance. Leadership wants to understand:

- How much are we selling, and is it growing month over month?
- Which products, categories, and states drive the most revenue?
- How do customers pay, and where do they shop?
- Who are our most valuable customers?
- Are discounts actually working, or just eating into margin?

This project answers those questions with a single, self-contained analysis.

## Tools Used

- **Microsoft Excel** — data cleaning checks, pivot-style formula analysis, KPI dashboard, native charts
- **Python** — pandas (cleaning & analysis), Matplotlib (charts), openpyxl (Excel export)
- **MySQL** — relational schema + analysis queries
- **GitHub** — version control & portfolio hosting

## Key Analysis

Both the Excel workbook and the Python script independently calculate the same core metrics from the cleaned dataset:

- Total Sales, Total Orders, Total Quantity Sold, Average Order Value, Total Customers, Average Discount
- Monthly sales trend (Jan–Dec 2025)
- Sales by Product Category, State, Payment Mode, and Sales Channel
- Top 10 Products and Top 10 Customers by revenue

All Excel numbers are driven by live formulas (`SUMIFS`, `COUNTIFS`, `AVERAGE`, `RANK` + `INDEX`/`MATCH`) referencing the cleaned data — nothing is hardcoded, so the workbook recalculates if the underlying data changes.

## Dashboard

`excel/Sales_Performance_Dashboard.xlsx` contains 5 sheets:

| Sheet | Contents |
|---|---|
| **Dashboard** | 5 KPI cards + 6 charts (monthly trend, category, state, payment mode, sales channel, top 10 products) — designed to be understood in under 30 seconds |
| **Raw_Data** | The original, unmodified dataset (1,262 rows) — includes intentional duplicates, missing values, and bad date formats for the cleaning exercise |
| **Data_Cleaning** | Live formulas checking duplicate records, missing values, invalid ages, malformed dates, duplicate Order_IDs, and before/after record counts |
| **Clean_Data** | The cleaned dataset (1,246 rows) that powers every formula on the Analysis and Dashboard sheets |
| **Analysis** | KPIs and full pivot-style breakdowns (month, category, state, payment mode, channel, top 10 products, top 10 customers) |

**Note on slicers:** true Excel slicers only attach to native PivotTables, and PivotTable/slicer objects aren't reliably supported by the automated tooling used to build this file. Instead, `Raw_Data` and `Clean_Data` are formatted as Excel Tables with AutoFilter dropdowns on every column (Year/Month, State, Category, Channel, Payment Mode all filterable that way). If you want true slicers, the quickest path is: select the Clean_Data table in Excel → Insert → PivotTable → build the same breakdowns → Insert → Slicer.

## Business Insights

Full write-up in [`business_insights.md`](business_insights.md). Highlights:

- **Electronics drives 63.8% of all revenue**, led by Laptops (₹24.7L) and Tablets (₹12.4L)
- **July (₹10.98L) was the strongest month**, January (₹4.22L) the weakest
- **Online is the top channel (44.9%)**, ahead of In-Store (31.3%) and Mobile App (23.8%)
- **UPI leads payment methods at 33.7%** of sales, roughly double any single card method
- **Higher discounts correlate with smaller average orders**, not larger ones (₹8,672 AOV at 0% discount vs. ₹3,834 at 21%+)
- **The Top 10 customers (1.3% of customers) drive 17.9% of revenue** — a strong case for a loyalty program

## Project Structure

```
Sales-Performance-Customer-Insights/
│
├── data/
│   ├── sales_data_raw.csv              # Raw dataset (with intentional data-quality issues)
│   ├── sales_data_cleaned.csv          # Cleaned dataset (used by Excel & SQL)
│   └── analysis_results.xlsx           # KPI/analysis tables exported by the Python script
│
├── excel/
│   └── Sales_Performance_Dashboard.xlsx
│
├── python/
│   └── sales_analysis.py
│
├── sql/
│   └── sales_analysis.sql
│
├── charts/
│   ├── monthly_sales.png
│   ├── category_sales.png
│   ├── state_sales.png
│   └── top_products.png
│
├── business_insights.md
├── README.md
└── requirements.txt
```

## How to Run

### Python
```bash
# from the project root
pip install -r requirements.txt
cd python
python sales_analysis.py
```
This reads `data/sales_data_raw.csv`, cleans it, prints every check and KPI to the console, writes `data/sales_data_cleaned.csv` and `data/analysis_results.xlsx`, and regenerates the four charts in `charts/`. No manual edits are required — it runs as-is.

### SQL (MySQL)
```bash
mysql -u your_username -p < sql/sales_analysis.sql
```
This creates the `sales_performance_db` database and `sales_data` table, and includes commented instructions for loading `data/sales_data_cleaned.csv` via `LOAD DATA LOCAL INFILE`. Once loaded, run any of the analysis queries in the same file individually.

### Excel
Just open `excel/Sales_Performance_Dashboard.xlsx` in Microsoft Excel or LibreOffice Calc — everything is pre-calculated and ready to view. Open the **Dashboard** tab first.

---

## Uploading to GitHub

```bash
# 1. Create a new empty repository on GitHub named "Sales-Performance-Customer-Insights"
#    (do NOT initialize it with a README — you already have one)

# 2. From inside the project folder on your machine:
cd Sales-Performance-Customer-Insights
git init
git add .
git commit -m "Initial commit: Sales Performance & Customer Insights Dashboard"
git branch -M main
git remote add origin https://github.com/<your-username>/Sales-Performance-Customer-Insights.git
git push -u origin main
```

If Excel/PNG files are large, consider enabling [Git LFS](https://git-lfs.github.com/) before the first commit (`git lfs install && git lfs track "*.xlsx" "*.png"`).

---

## Resume Description

> **Sales Performance & Customer Insights Dashboard** — Personal Project
> - Built an end-to-end sales analytics pipeline in Python (pandas) and MySQL, cleaning 1,260+ transaction records (deduplication, missing-value handling, date standardization) and calculating 10+ KPIs across product, geography, and payment dimensions.
> - Designed a fully formula-driven Excel dashboard (SUMIFS, RANK/INDEX-MATCH, native charts) presenting monthly trends, top products/customers, and channel performance in a recruiter-readable, single-screen view.
> - Delivered a written business-insights report identifying a 63.8%-revenue category concentration risk and a discount strategy correlated with smaller basket sizes, translating raw data into actionable recommendations.
