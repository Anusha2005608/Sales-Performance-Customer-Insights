"""
sales_analysis.py
------------------
Sales Performance & Customer Insights Dashboard - Python Analysis

This script:
  1. Loads the raw sales dataset
  2. Checks for missing values and duplicates
  3. Cleans the dataset (fixes dates, drops bad rows, fills gaps)
  4. Calculates key business KPIs
  5. Analyzes sales by month, category, state, payment mode, channel
  6. Finds top-performing products, customers and states
  7. Exports the cleaned data and analysis results to CSV
  8. Generates professional charts (saved to charts/)

Run with:  python sales_analysis.py
Requires: pandas, matplotlib, openpyxl  (see requirements.txt)
"""

import os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

# ---------------------------------------------------------------------------
# 0. SETUP
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # project root
DATA_PATH = os.path.join(BASE_DIR, "data", "sales_data_raw.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "data")
CHARTS_DIR = os.path.join(BASE_DIR, "charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

plt.rcParams["font.family"] = "DejaVu Sans"
COLOR_PRIMARY = "#2E5EAA"
COLOR_ACCENT = "#F2A900"

print("=" * 70)
print("SALES PERFORMANCE & CUSTOMER INSIGHTS - PYTHON ANALYSIS")
print("=" * 70)

# ---------------------------------------------------------------------------
# 1. LOAD DATA
# ---------------------------------------------------------------------------
df = pd.read_csv(DATA_PATH)
print(f"\n[1] Loaded raw dataset: {df.shape[0]} rows, {df.shape[1]} columns")

# ---------------------------------------------------------------------------
# 2. CHECK MISSING VALUES
# ---------------------------------------------------------------------------
missing_summary = df.isnull().sum()
missing_summary = missing_summary[missing_summary > 0]
print("\n[2] Missing values per column:")
if len(missing_summary):
    print(missing_summary.to_string())
else:
    print("  None found.")

# ---------------------------------------------------------------------------
# 3. CHECK DUPLICATES
# ---------------------------------------------------------------------------
full_dupes = df.duplicated().sum()
order_id_dupes = df["Order_ID"].duplicated().sum()
print(f"\n[3] Fully duplicated rows: {full_dupes}")
print(f"    Duplicate Order_IDs: {order_id_dupes}")

# ---------------------------------------------------------------------------
# 4. CLEAN THE DATASET
# ---------------------------------------------------------------------------
rows_before = len(df)
df_clean = df.copy()

# 4a. Drop fully duplicated rows
df_clean = df_clean.drop_duplicates()

# 4b. Standardize Order_Date to a single format (handles YYYY-MM-DD, DD/MM/YYYY, MM-DD-YYYY)
def parse_date(val):
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m-%d-%Y"):
        try:
            return pd.to_datetime(val, format=fmt)
        except (ValueError, TypeError):
            continue
    return pd.NaT

df_clean["Order_Date"] = df_clean["Order_Date"].apply(parse_date)
df_clean = df_clean.dropna(subset=["Order_Date"])

# 4c. Remove rows with duplicate Order_ID, keeping the first occurrence
df_clean = df_clean.drop_duplicates(subset=["Order_ID"], keep="first")

# 4d. Fix invalid ages (must be between 15 and 90) -> replace with median age
valid_age_mask = df_clean["Age"].between(15, 90)
median_age = df_clean.loc[valid_age_mask, "Age"].median()
df_clean.loc[~valid_age_mask, "Age"] = median_age
df_clean["Age"] = df_clean["Age"].astype(int)

# 4e. Fill missing categorical values
# Customer_Name: recover from another row with the same Customer_ID first (a customer's
# name shouldn't change between orders), and only fall back to a placeholder if every
# row for that ID is missing the name. This avoids splitting one real customer into two
# rows during later groupby-by-ID-and-name aggregation.
name_lookup = (df_clean.dropna(subset=["Customer_Name"])
               .groupby("Customer_ID")["Customer_Name"].first())
df_clean["Customer_Name"] = df_clean.apply(
    lambda row: name_lookup.get(row["Customer_ID"], "Unknown Customer")
    if pd.isna(row["Customer_Name"]) else row["Customer_Name"], axis=1)
df_clean["City"] = df_clean["City"].fillna("Unknown City")
df_clean["Payment_Mode"] = df_clean["Payment_Mode"].fillna("Unknown")

# 4f. Fill missing discount with 0 (no discount applied)
df_clean["Discount"] = df_clean["Discount"].fillna(0)

# 4g. Recalculate Sales to guarantee formula integrity: Sales = Qty * Unit_Price * (1 - Discount)
df_clean["Sales"] = (df_clean["Quantity"] * df_clean["Unit_Price"] * (1 - df_clean["Discount"])).round(2)

# 4h. Add helper columns used in analysis
df_clean["Order_Month"] = df_clean["Order_Date"].dt.to_period("M").astype(str)
df_clean["Order_Date"] = df_clean["Order_Date"].dt.strftime("%Y-%m-%d")

rows_after = len(df_clean)
print(f"\n[4] Cleaning complete.")
print(f"    Rows before cleaning: {rows_before}")
print(f"    Rows after cleaning:  {rows_after}")
print(f"    Rows removed:         {rows_before - rows_after}")

df_clean.to_csv(os.path.join(OUTPUT_DIR, "sales_data_cleaned.csv"), index=False)
print(f"    Cleaned data exported to: data/sales_data_cleaned.csv")

# ---------------------------------------------------------------------------
# 5. KEY PERFORMANCE INDICATORS (KPIs)
# ---------------------------------------------------------------------------
total_sales = df_clean["Sales"].sum()
total_orders = df_clean["Order_ID"].nunique()
total_quantity = df_clean["Quantity"].sum()
avg_order_value = total_sales / total_orders
total_customers = df_clean["Customer_ID"].nunique()
avg_discount = df_clean["Discount"].mean()

kpis = pd.DataFrame({
    "KPI": ["Total Sales", "Total Orders", "Total Quantity Sold", "Average Order Value",
            "Total Customers", "Average Discount"],
    "Value": [round(total_sales, 2), total_orders, int(total_quantity),
              round(avg_order_value, 2), total_customers, round(avg_discount, 4)]
})
print("\n[5] KPIs:")
print(kpis.to_string(index=False))

# ---------------------------------------------------------------------------
# 6. MONTHLY SALES TREND
# ---------------------------------------------------------------------------
monthly_sales = df_clean.groupby("Order_Month")["Sales"].sum().sort_index().reset_index()
monthly_sales.columns = ["Month", "Total_Sales"]
print("\n[6] Sales by Month:")
print(monthly_sales.to_string(index=False))

# ---------------------------------------------------------------------------
# 7. CATEGORY PERFORMANCE
# ---------------------------------------------------------------------------
category_sales = (df_clean.groupby("Product_Category")["Sales"].sum()
                   .sort_values(ascending=False).reset_index())
category_sales.columns = ["Product_Category", "Total_Sales"]
print("\n[7] Sales by Product Category:")
print(category_sales.to_string(index=False))

# ---------------------------------------------------------------------------
# 8. STATE PERFORMANCE
# ---------------------------------------------------------------------------
state_sales = (df_clean.groupby("State")["Sales"].sum()
               .sort_values(ascending=False).reset_index())
state_sales.columns = ["State", "Total_Sales"]
print("\n[8] Sales by State (Top 10):")
print(state_sales.head(10).to_string(index=False))

# ---------------------------------------------------------------------------
# 9. PAYMENT MODE & SALES CHANNEL
# ---------------------------------------------------------------------------
payment_sales = (df_clean.groupby("Payment_Mode")["Sales"].sum()
                  .sort_values(ascending=False).reset_index())
payment_sales.columns = ["Payment_Mode", "Total_Sales"]

channel_sales = (df_clean.groupby("Sales_Channel")["Sales"].sum()
                  .sort_values(ascending=False).reset_index())
channel_sales.columns = ["Sales_Channel", "Total_Sales"]

print("\n[9] Sales by Payment Mode:")
print(payment_sales.to_string(index=False))
print("\n    Sales by Sales Channel:")
print(channel_sales.to_string(index=False))

# ---------------------------------------------------------------------------
# 10. TOP PRODUCTS & TOP CUSTOMERS
# ---------------------------------------------------------------------------
top_products = (df_clean.groupby("Product")["Sales"].sum()
                 .sort_values(ascending=False).head(10).reset_index())
top_products.columns = ["Product", "Total_Sales"]

top_customers = (df_clean.groupby(["Customer_ID", "Customer_Name"])["Sales"].sum()
                  .sort_values(ascending=False).head(10).reset_index())
top_customers.columns = ["Customer_ID", "Customer_Name", "Total_Sales"]

print("\n[10] Top 10 Products by Sales:")
print(top_products.to_string(index=False))
print("\n     Top 10 Customers by Sales:")
print(top_customers.to_string(index=False))

# ---------------------------------------------------------------------------
# 11. EXPORT ANALYSIS RESULTS
# ---------------------------------------------------------------------------
with pd.ExcelWriter(os.path.join(OUTPUT_DIR, "analysis_results.xlsx"), engine="openpyxl") as writer:
    kpis.to_excel(writer, sheet_name="KPIs", index=False)
    monthly_sales.to_excel(writer, sheet_name="Monthly_Sales", index=False)
    category_sales.to_excel(writer, sheet_name="Category_Sales", index=False)
    state_sales.to_excel(writer, sheet_name="State_Sales", index=False)
    payment_sales.to_excel(writer, sheet_name="Payment_Sales", index=False)
    channel_sales.to_excel(writer, sheet_name="Channel_Sales", index=False)
    top_products.to_excel(writer, sheet_name="Top_Products", index=False)
    top_customers.to_excel(writer, sheet_name="Top_Customers", index=False)
print(f"\n[11] Analysis results exported to: data/analysis_results.xlsx")

# ---------------------------------------------------------------------------
# 12. CHARTS
# ---------------------------------------------------------------------------

def format_axis_in_lakhs(ax):
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/100000:.1f}L"))

# 12a. Monthly Sales Trend (line chart)
fig, ax = plt.subplots(figsize=(9, 5))
ax.plot(monthly_sales["Month"], monthly_sales["Total_Sales"], marker="o",
        color=COLOR_PRIMARY, linewidth=2)
ax.set_title("Monthly Sales Trend - 2025", fontsize=14, fontweight="bold")
ax.set_xlabel("Month")
ax.set_ylabel("Total Sales (₹)")
plt.xticks(rotation=45, ha="right")
format_axis_in_lakhs(ax)
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "monthly_sales.png"), dpi=150)
plt.close()

# 12b. Category Sales (bar chart)
fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(category_sales["Product_Category"], category_sales["Total_Sales"], color=COLOR_PRIMARY)
ax.set_title("Sales by Product Category", fontsize=14, fontweight="bold")
ax.set_ylabel("Total Sales (₹)")
plt.xticks(rotation=30, ha="right")
format_axis_in_lakhs(ax)
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "category_sales.png"), dpi=150)
plt.close()

# 12c. State Sales (top 10, horizontal bar)
top_states = state_sales.head(10).sort_values("Total_Sales")
fig, ax = plt.subplots(figsize=(9, 5))
ax.barh(top_states["State"], top_states["Total_Sales"], color=COLOR_ACCENT)
ax.set_title("Top 10 States by Sales", fontsize=14, fontweight="bold")
ax.set_xlabel("Total Sales (₹)")
format_axis_in_lakhs(ax)
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "state_sales.png"), dpi=150)
plt.close()

# 12d. Top 10 Products (horizontal bar)
top_products_sorted = top_products.sort_values("Total_Sales")
fig, ax = plt.subplots(figsize=(9, 5))
ax.barh(top_products_sorted["Product"], top_products_sorted["Total_Sales"], color=COLOR_PRIMARY)
ax.set_title("Top 10 Products by Sales", fontsize=14, fontweight="bold")
ax.set_xlabel("Total Sales (₹)")
format_axis_in_lakhs(ax)
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "top_products.png"), dpi=150)
plt.close()

print(f"\n[12] Charts saved to: {CHARTS_DIR}")
print("      - monthly_sales.png")
print("      - category_sales.png")
print("      - state_sales.png")
print("      - top_products.png")

print("\n" + "=" * 70)
print("ANALYSIS COMPLETE")
print("=" * 70)
