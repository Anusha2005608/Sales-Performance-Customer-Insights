-- =============================================================================
-- sales_analysis.sql
-- Sales Performance & Customer Insights Dashboard
-- MySQL-compatible schema + analysis queries
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. DATABASE & TABLE SETUP
-- -----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS sales_performance_db;
USE sales_performance_db;

DROP TABLE IF EXISTS sales_data;

CREATE TABLE sales_data (
    Order_ID          VARCHAR(15)     NOT NULL,
    Order_Date        DATE            NOT NULL,
    Customer_ID       VARCHAR(15)     NOT NULL,
    Customer_Name     VARCHAR(100)    NOT NULL,
    Gender            VARCHAR(10),
    Age               INT,
    City              VARCHAR(50),
    State             VARCHAR(50),
    Product_Category  VARCHAR(50)     NOT NULL,
    Product            VARCHAR(100)    NOT NULL,
    Quantity          INT             NOT NULL,
    Unit_Price        DECIMAL(10,2)   NOT NULL,
    Discount          DECIMAL(4,2)    NOT NULL DEFAULT 0,
    Sales             DECIMAL(12,2)   NOT NULL,
    Payment_Mode      VARCHAR(30),
    Sales_Channel     VARCHAR(20),
    PRIMARY KEY (Order_ID),
    INDEX idx_customer (Customer_ID),
    INDEX idx_date (Order_Date),
    INDEX idx_category (Product_Category),
    INDEX idx_state (State)
);

-- -----------------------------------------------------------------------------
-- 2. LOAD DATA
-- -----------------------------------------------------------------------------
-- Option A: Load directly from the cleaned CSV (adjust path & enable
-- local_infile on the MySQL server/client first: SET GLOBAL local_infile = 1;)
--
-- LOAD DATA LOCAL INFILE 'data/sales_data_cleaned.csv'
-- INTO TABLE sales_data
-- FIELDS TERMINATED BY ','
-- OPTIONALLY ENCLOSED BY '"'
-- LINES TERMINATED BY '\n'
-- IGNORE 1 ROWS
-- (Order_ID, Order_Date, Customer_ID, Customer_Name, Gender, Age, City, State,
--  Product_Category, Product, Quantity, Unit_Price, Discount, Sales,
--  Payment_Mode, Sales_Channel, @Order_Month);
--
-- Option B: Use the companion Python loader (see README "How to Run") which
-- reads sales_data_cleaned.csv with pandas and writes it to this table via
-- SQLAlchemy - useful when LOAD DATA LOCAL INFILE is disabled on your server.

-- -----------------------------------------------------------------------------
-- 3. CORE KPI QUERIES
-- -----------------------------------------------------------------------------

-- 3.1 Total Sales
SELECT ROUND(SUM(Sales), 2) AS Total_Sales
FROM sales_data;

-- 3.2 Total Orders
SELECT COUNT(DISTINCT Order_ID) AS Total_Orders
FROM sales_data;

-- 3.3 Total Customers
SELECT COUNT(DISTINCT Customer_ID) AS Total_Customers
FROM sales_data;

-- 3.4 Average Order Value
SELECT ROUND(SUM(Sales) / COUNT(DISTINCT Order_ID), 2) AS Average_Order_Value
FROM sales_data;

-- 3.5 Total Quantity Sold
SELECT SUM(Quantity) AS Total_Quantity_Sold
FROM sales_data;

-- 3.6 Average Discount
SELECT ROUND(AVG(Discount), 4) AS Average_Discount
FROM sales_data;

-- -----------------------------------------------------------------------------
-- 4. MONTHLY SALES TREND
-- -----------------------------------------------------------------------------
SELECT
    DATE_FORMAT(Order_Date, '%Y-%m') AS Order_Month,
    ROUND(SUM(Sales), 2)             AS Total_Sales,
    COUNT(DISTINCT Order_ID)         AS Total_Orders
FROM sales_data
GROUP BY DATE_FORMAT(Order_Date, '%Y-%m')
ORDER BY Order_Month;

-- -----------------------------------------------------------------------------
-- 5. SALES BY PRODUCT CATEGORY
-- -----------------------------------------------------------------------------
SELECT
    Product_Category,
    ROUND(SUM(Sales), 2)     AS Total_Sales,
    COUNT(DISTINCT Order_ID) AS Total_Orders,
    ROUND(AVG(Sales), 2)     AS Avg_Order_Value
FROM sales_data
GROUP BY Product_Category
ORDER BY Total_Sales DESC;

-- -----------------------------------------------------------------------------
-- 6. SALES BY STATE
-- -----------------------------------------------------------------------------
SELECT
    State,
    ROUND(SUM(Sales), 2)     AS Total_Sales,
    COUNT(DISTINCT Order_ID) AS Total_Orders
FROM sales_data
GROUP BY State
ORDER BY Total_Sales DESC;

-- -----------------------------------------------------------------------------
-- 7. TOP 10 PRODUCTS BY SALES
-- -----------------------------------------------------------------------------
SELECT
    Product,
    Product_Category,
    ROUND(SUM(Sales), 2) AS Total_Sales,
    SUM(Quantity)         AS Total_Units_Sold
FROM sales_data
GROUP BY Product, Product_Category
ORDER BY Total_Sales DESC
LIMIT 10;

-- -----------------------------------------------------------------------------
-- 8. TOP 10 CUSTOMERS BY SALES
-- -----------------------------------------------------------------------------
SELECT
    Customer_ID,
    Customer_Name,
    ROUND(SUM(Sales), 2)     AS Total_Sales,
    COUNT(DISTINCT Order_ID) AS Total_Orders
FROM sales_data
GROUP BY Customer_ID, Customer_Name
ORDER BY Total_Sales DESC
LIMIT 10;

-- -----------------------------------------------------------------------------
-- 9. SALES BY PAYMENT MODE
-- -----------------------------------------------------------------------------
SELECT
    Payment_Mode,
    ROUND(SUM(Sales), 2)     AS Total_Sales,
    COUNT(DISTINCT Order_ID) AS Total_Orders
FROM sales_data
GROUP BY Payment_Mode
ORDER BY Total_Sales DESC;

-- -----------------------------------------------------------------------------
-- 10. SALES BY SALES CHANNEL
-- -----------------------------------------------------------------------------
SELECT
    Sales_Channel,
    ROUND(SUM(Sales), 2)     AS Total_Sales,
    COUNT(DISTINCT Order_ID) AS Total_Orders
FROM sales_data
GROUP BY Sales_Channel
ORDER BY Total_Sales DESC;

-- -----------------------------------------------------------------------------
-- 11. BONUS: ADDITIONAL BUSINESS QUERIES
-- -----------------------------------------------------------------------------

-- 11.1 Sales & average order value by gender
SELECT
    Gender,
    ROUND(SUM(Sales), 2) AS Total_Sales,
    ROUND(AVG(Sales), 2) AS Avg_Order_Value,
    COUNT(DISTINCT Order_ID) AS Total_Orders
FROM sales_data
GROUP BY Gender;

-- 11.2 Sales by day of week (checks for weekday vs weekend patterns)
SELECT
    DAYNAME(Order_Date) AS Day_Of_Week,
    ROUND(SUM(Sales), 2) AS Total_Sales
FROM sales_data
GROUP BY DAYNAME(Order_Date), DAYOFWEEK(Order_Date)
ORDER BY DAYOFWEEK(Order_Date);

-- 11.3 Average order value by discount band (does a higher discount
--      actually correlate with a bigger basket?)
SELECT
    CASE
        WHEN Discount = 0        THEN '0%'
        WHEN Discount <= 0.05    THEN '1-5%'
        WHEN Discount <= 0.10    THEN '6-10%'
        WHEN Discount <= 0.15    THEN '11-15%'
        WHEN Discount <= 0.20    THEN '16-20%'
        ELSE '21%+'
    END AS Discount_Band,
    ROUND(AVG(Sales), 2) AS Avg_Order_Value,
    COUNT(*)             AS Num_Orders
FROM sales_data
GROUP BY Discount_Band
ORDER BY MIN(Discount);

-- 11.4 Repeat customers (customers with more than one order)
SELECT
    COUNT(*) AS Repeat_Customers
FROM (
    SELECT Customer_ID
    FROM sales_data
    GROUP BY Customer_ID
    HAVING COUNT(DISTINCT Order_ID) > 1
) AS repeat_cust;

-- 11.5 Top state within each product category (illustrates window functions,
--      MySQL 8.0+)
SELECT Product_Category, State, Total_Sales
FROM (
    SELECT
        Product_Category,
        State,
        ROUND(SUM(Sales), 2) AS Total_Sales,
        RANK() OVER (PARTITION BY Product_Category ORDER BY SUM(Sales) DESC) AS rnk
    FROM sales_data
    GROUP BY Product_Category, State
) ranked
WHERE rnk = 1;
