# Business Insights — Sales Performance & Customer Insights Dashboard

*All figures below were calculated from the cleaned dataset (1,246 orders, Jan–Dec 2025) using `python/sales_analysis.py`. Nothing here was written before running the analysis — the numbers come first, the insight is written to match them.*

---

### 1. July was the strongest month; January was the weakest
Monthly sales ranged from **₹4.22L in January** to **₹10.98L in July**, a ~2.6x swing. July and October (₹10.69L) were the two standout months, both roughly 20% above the yearly monthly average (~₹7.53L). There's no single obvious seasonal driver in a synthetic dataset like this, but in a real business this pattern would be worth cross-checking against promotions, paydays, or festival calendars.

### 2. Electronics dominates revenue — almost two-thirds of all sales
**Electronics generated ₹57.6L, or 63.8% of total sales**, from just 8 of the 45 products sold. Home & Kitchen (₹9.6L) and Sports & Fitness (₹7.1L) were a distant second and third. This concentration means the business is highly exposed to Electronics category performance — a slowdown there would hit total revenue hard.

### 3. Laptops and Tablets are the two best-selling products by a wide margin
The **Laptop (₹24.7L) and Tablet (₹12.4L)** together account for over 40% of total sales, more than the next 8 products in the Top 10 combined. Smartphones (₹8.1L) and LED Monitors (₹7.9L) round out the top four — all four are Electronics, reinforcing insight #2.

### 4. West Bengal, Delhi and Gujarat are the leading states
**West Bengal (₹11.3L), Delhi (₹10.3L) and Gujarat (₹9.4L)** were the top three states, together contributing about a third of total revenue. The top state (West Bengal) alone represents 12.6% of all sales. Sales are reasonably well spread across the other 9 states/regions, so there's no single point of geographic failure, but these three merit priority for regional marketing spend.

### 5. Online is the leading sales channel, but not by an overwhelming margin
**Online sales reached ₹40.5L (44.9% of total)**, ahead of In-Store (₹28.3L, 31.3%) and Mobile App (₹21.5L, 23.8%). The gap between Online and In-Store is meaningful but not dominant — this business still has a healthy offline presence, and the Mobile App channel (smallest of the three) has clear room to grow relative to Online.

### 6. UPI is the most-used payment method, well ahead of cards
**UPI processed ₹30.4L (33.7% of sales)** — roughly double any single card-based method. Debit Card, Cash on Delivery, Net Banking and Credit Card are all clustered tightly together at 16–17% each. This mirrors the real-world shift toward UPI in the Indian market and suggests checkout flows should be optimized UPI-first.

### 7. Discounts do not appear to drive larger orders — the opposite trend shows up
Average order value **falls as the discount band increases**: ₹8,672 at 0% discount vs. ₹6,111 at 10% and just ₹3,834 at 21%+ discount. In this dataset, heavier discounting is associated with *smaller* average baskets, not larger ones — a signal that discounts here are being used on lower-value items rather than to upsell, and are not obviously paying for themselves in basket size. This is worth validating against margin data before drawing conclusions.

### 8. A meaningful share of revenue comes from repeat customers
**301 of 778 customers (38.7%) placed more than one order**, and the **Top 10 customers together contributed ₹1.62L (17.9%) of total sales** despite being just 1.3% of the customer base. Retaining this small group of high-value repeat customers matters disproportionately to revenue — a loyalty or VIP program targeted at them could have outsized impact.

### 9. Male customers show a slightly higher average order value than female customers
Male customers generated **₹48.6L in total sales at an average order value of ₹7,560**, versus **₹41.7L at ₹6,919** for female customers. The gap (~9%) is modest but consistent, and total order counts were similar between genders (643 vs. 603), so this isn't just a volume effect.

### 10. Areas with room for improvement
- **Groceries and Books & Stationery are the weakest categories** (₹1.5L and ₹2.9L respectively, under 5% of total sales combined) — either a genuine low-demand category or an assortment/pricing gap worth investigating.
- **"Unknown" payment mode still accounts for ₹71K in sales** — a small but avoidable data-quality gap; checkout logging should always capture a valid payment method.
- **Tamil Nadu and Uttar Pradesh are the lowest-performing of the tracked states** (₹4.3L and ₹4.6L, both under half the leading state's total) — worth a closer look at regional demand or store/delivery coverage before investing further marketing spend there.

---

*Insights generated from `data/sales_data_cleaned.csv` via `python/sales_analysis.py`. Re-run the script after refreshing the dataset to regenerate these figures.*
